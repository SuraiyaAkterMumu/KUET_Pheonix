#define ll long long int
#define mx 100005
bool vis[mx];
int n,m,p[mx];

void cycle(int u,int pu=-1){//here pu means parent
      p[u]=pu;
      vis[u] = 1;
      for(int v:adj[u]){
            if(v==pu)
                  continue;
            if(vis[v]){
                 int u2 = u;
                 while(u^v){
                     ans.push_back(u);
                     u = p[u];
                    ///same hoile u^v=0 hoile
                 }
                 ans.push_back(v);
                 ans.push_back(u2);
                 cout<<ans.size()<<endl;
                 for(int a:ans)
                    cout << a+1 <<" ";
                 exit(0);
            }else{
                dfs(v,u);
            }
      }
 
}