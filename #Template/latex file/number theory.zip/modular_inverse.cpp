pii extended_euclid(lli a,lli b){
        if(b==0){
                return pii(1,0);
        }else{
                pii d = extended_euclid(b,a%b);
                return pii(d.ss,d.ff-d.ss*(a/b));
        }
}

lli modular_inverse(lli a){
    pii ret = extended_euclid(a,mod);
    return ((ret.ff%mod)+mod)%mod;

}