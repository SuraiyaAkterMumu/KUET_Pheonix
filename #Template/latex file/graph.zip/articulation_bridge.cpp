vector<int>adj[mx];
int visited[mx],node[mx],low[mx], parent[mx],disTime[mx],discover_time,root;
set<pii>s;

void articulation_bridge(int u)
{
    visited[u]=1;
    int cnt=0;
    disTime[u]=low[u]=++discover_time;
    for(int i=0; i<adj[u].size(); i++)
    {
        int v=adj[u][i];
        if(parent[u]==v)
            continue;
        if(visited[v])
            low[u]=min(low[u],disTime[v]); //back edge thakle
        else
        {
            parent[v]=u;
            articulation_point(v);
            low[u]=min(low[u],low[v]);
            if(disTime[u]<low[v])
            {
                s.insert({min(u,v),max(u,v)});
                //cout<<u<<" "<<v<<endl;
                //node[u]=1;
            }

        }


    }


}

int main()
{
        s.clear();
        int node;
        sf("%d",&node);
        for(int i=1; i<=node; i++)
        {
            int u,n;
            char c1,c2;
            cin>>u;
            getchar();
            cin>>c1>>n>>c2;
            for(int nn=1; nn<=n; nn++)
            {
                int v;
                cin>>v;
                adj[u].pb(v);
            }
        }
        for(int i=0; i<node; i++)
        {
            root=i;
            if(!visited[i])
            {
                articulation_point(i);
            }
        }
}
