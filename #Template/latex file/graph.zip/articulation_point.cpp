vector<int>adj[mx];
int visited[mx], node[mx], low[mx], parent[mx], disTime[mx], discover_time, root;


void articulation_point(int u)
{
    visited[u]=1;
    int cnt=0;
    disTime[u]=low[u]=++discover_time;
    for(int i=0; i<adj[u].size(); i++)
    {
        int v=adj[u][i];
        if(parent[u]==v)
            continue;
        if(visited[v]) low[u]=min(low[u],disTime[v]); //back edge thakle
         else
        {
            parent[v]=u;
            articulation_point(v);
            low[u]=min(low[u],low[v]);
            if(disTime[u]<=low[v] && u!=root)
            {
                node[u]=1;
            }
           cnt++;
        }


    }
    if(cnt>1 && u==root)
        node[u]=1;

}

int main()
{
        memset(visited,0,sizeof visited);
        memset(node,0,sizeof node);
        memset(low,0,sizeof low);
        memset(disTime,0,sizeof disTime);
        discover_time=0;
        for(int i=0; i<mx; i++)
            adj[i].clear();
        int edge,n;
        sf("%d%d",&n,&edge);
        for(int i=1; i<=edge; i++)
        {
            int u,v;
           sf("%d%d",&u,&v);
            adj[u].pb(v);
            adj[v].pb(u);
        }
        root=1;
        articulation_point(1);
}
