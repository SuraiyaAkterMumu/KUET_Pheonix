void segmented_seive(lli l,lli r)
{
    bool isPrime[r-l+1];
    mem(isPrime,1);
    if(l==1)
        isPrime[0]=false;

    for(lli i=0;prime[i]*prime[i]<=r;i++ )
    {
        lli curPrime=prime[i];
        lli base=curPrime*curPrime;
        if(base<l)
            base=((l+curPrime-1)/curPrime)*curPrime;
        for(lli j=base;j<=r;j+=curPrime)
        {
                isPrime[j-l]=false;
        }

    }
    vector<lli>v;
        for(lli i=0;i<=r-l;i++)
        {
                if(isPrime[i]==true)
                    {v.pb(l+i);}
        }
}