#include<bits/stdc++.h>
#include<iostream>
#include<math.h>
#include<vector>
#include<set>
#include<queue>
#include<algorithm>
#include<cstring>    //for memset
using namespace std;

// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
// using namespace __gnu_pbds;
//find_by_order(k) – 
//order_of_key(x) – 

#define lli                      int long long
#define ull                      unsigned long long
#define ld                       long double
#define pi                       acos(-1)
#define pb                       push_back
#define pbk                      pop_back
#define mp                       make_pair
#define ff                       first
#define ss                       second
#define pii                      pair<int,int>
#define gcd(a,b)                 __gcd(a,b)
#define lcm(a,b)                (a/gcd(a,b))*b
#define READ                     freopen("in.txt","r",stdin);
#define WRITE                    freopen("outer.txt","w",stdout);
#define sort(t)                  sort(t.begin(),t.end())
#define mem(a,b)                 memset(a,b,sizeof a)
#define TEST_CASE(t)             for(int z=1;z<=t;z++)
#define PRINT_CASE               printf("Case %d: ",z)
#define LINE_PRINT_CASE          printf("Case %d:\n",z)
#define ordered_set              tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update>
#define sf                       scanf
#define pf                       printf
#define dist(ax,ay,bx,by)        sqrt((ax-bx)*(ax-bx)+(ay-by)*(ay-by))
#define EQUAL_RANGE(set)         pair<set<int>::const_iterator,set<int>::const_iterator> ret; ret=myset.equal_range(30);
#define MX                       100003
#define inf                      10000000000000000+7
#define M                        1000000002
#define MINI                     -1000000003

/*----------------------Graph Moves----------------*/
//const int fx[]={+1,-1,+0,+0};
//const int fy[]={+0,+0,+1,-1};
//const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};   // Kings Move
//const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};  // Kings Move
//const int fx[]={-2, -2, -1, -1,  1,  1,  2,  2};  // Knights Move
//const int fy[]={-1,  1, -2,  2, -2,  2, -1,  1}; // Knights Move
//const int fx[] = {2, -2, 1, 1, -1, -1} ;
//const int fy[] = {0,0,1,-1,1,-1};             // Hexagonal Direction
 //int day[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; 
/*------------------------------------------------*/

int main(){

}
