//we can do modular multiplication inverse
//by it,,if m is prime..-->O(log(p))
//done using concept of bit manipulation,
//faster than recurtion

int bigmod ( int b, int p, int m ) {
    int res = 1 % m, x = b % m;
    while ( p ) {
        if ( p & 1 ) //check if 0th bit is 1
           res = ( res * x ) % m;
        x = ( x * x ) % m;
        p >>= 1; //right shift so that we can work only with 0th bit
    }
    return res;
}