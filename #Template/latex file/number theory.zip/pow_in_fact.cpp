int get_power(int p,int q)//p! এর মধ্যে  q এর power কত 
{
    int i=q,cnt=0;
    while(p/i>=1)
    {
        int d=p/i;
        cnt+=d;
        i*=q;
    }
    cout<<"cnt - "<<cnt<<endl;
    return cnt;
}