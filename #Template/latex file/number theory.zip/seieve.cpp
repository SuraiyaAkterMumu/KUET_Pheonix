#define mx 100000005

int isprime[mx];
vector<int>prime;

void seive()
{   
    for(int i=4; i<mx; i+=2){
        isprime[i]=1;
    }
    isprime[0]=isprime[1]=1;
    for(int i=3; i*i<mx; i+=2){
        if(isprime[i]==0){
            for(int j=i*i; j<mx; j+=i+i)
                isprime[j]=1;
        }
    }prime.push_back(2);
    for(int i=3;i<mx;i+=2){
        if(!isprime[i]) prime.push_back(i);
    }
}
