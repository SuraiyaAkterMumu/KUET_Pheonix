#define int long long int
#define pii pair<int,int>
const int inf=9e15;
int node,edge,k;
vector<pair<int,int>>adj[200005];
// bool vis[200005]; // as a node can be visited many time
vector<vector<int>>dis;
 
void dijkstra(int s)
{
    dis.resize(200005);
    for(int i=0;i<200005;i++) 
    {
        dis[i].resize(k);
        for(int j=0;j<k;j++){
            dis[i][j]=inf;
        }
    }
    priority_queue<pii,vector<pii>,greater<pii>>pq;
 
    pq.push({0,s});
    
    while(!pq.empty())
    {
        int u=pq.top().second;
        int d= pq.top().first;
         pq.pop();
        
        if(dis[u][k-1]<d) continue;
        for(auto x:adj[u]){
            int vx=x.first;
            int vy=x.second;
            if(dis[vx][k-1]>d+vy)
            {
                dis[vx][k-1]=d+vy;
                
                pq.push({dis[vx][k-1],vx});
                sort(dis[vx].begin(),dis[vx].end());
		
            }
        }
    }
} 
