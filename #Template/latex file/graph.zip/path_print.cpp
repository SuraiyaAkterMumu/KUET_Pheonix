char adj[1005][1005];
int visited[1005][1005];
const int fx[]= {+1,-1,+0,+0};
const int fy[]= {+0,+0,+1,-1};
string path="";
int R,C;
map<pair<int,int>,pair<pair<int,int>,char> >parent;
string  bfs(int sx,int sy,int dx,int dy){
    
int ux,uy,vx,vy;
visited[sx][sy]=true;

queue<int>q;
q.push(sx);
q.push(sy);
while(!q.empty())
{
    ux=q.front();
    q.pop();
    uy=q.front();
    q.pop();
    //cout<<ux<<" "<<uy<<endl;
    for(int i=0; i<4; i++)
    {
        vx=ux+fx[i];
        vy=uy+fy[i];
        if((vx>=0&&vx<R)&&(vy>=0&&vy<C)&& adj[vx][vy]!='#')
        {
            char dir ;
            if(i==0) dir = 'D';
            if(i==1) dir = 'U';
            if(i==2) dir = 'R';
            if(i==3) dir = 'L';
            if(!visited[vx][vy])
            {
                visited[vx][vy]=true;
                parent[ {vx,vy}]=make_pair(make_pair(ux,uy),dir);
                if(vx == dx && vy == dy)
                {
                    auto end = make_pair(vx,vy);
                    while(true)
                    {
                        path += parent[end].second;
                        end=parent[end].first;
                        if(end.first == sx && end.second == sy)
                            return path;
                    }

                }
                q.push(vx);
                q.push(vy);
            }
        }
    }
}

return path;
}

