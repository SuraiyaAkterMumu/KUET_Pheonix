int number_of_divisor(int n) ///have to generete prime using seive
{       
        long long int j=0,div=1;
	while(prime[j]*prime[j]<=n)
         {
		 
                long long int d=1;
                while(n%prime[j]==0)
                {
                    n/=prime[j];
                    d++; 
                }
                 
                div*=d;

                j++;
            }

            if(n!=1) div*=2; 
	    return div; 
} //disisor count with 1 and n itself