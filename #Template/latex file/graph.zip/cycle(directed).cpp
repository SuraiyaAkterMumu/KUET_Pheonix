#define ll long long int
#define mx 100005
vector<int>adj[mx],ans;
bool vis[mx];
int color[mx];
int n,m,p[mx];
 
void dfs(int u,int pu=-1){//here pu means parent
      p[u]=pu;
      vis[u] = 1;
      for(int v:adj[u]){
            if(vis[v] == 1 && color[v]!=2){
                 int u2 = u;
                 while(u^v){
                     ans.push_back(u);
                     u = p[u];
                    ///same hoile u^v=0 hoile
                 }
                 ans.push_back(v);
                 ans.push_back(u2);
                 cout<<ans.size()<<endl;
                 reverse(ans.begin(),ans.end());
                 for(int a:ans)
                    cout << a+1 <<" ";
                 exit(0);
            }else{
                dfs(v,u);
            }
      }
      color[u]=2;
 
}