vector<pair<int,int>>prime_fact;
void  prime_factor(int a)
{
    for(int i=0; prime[i]*prime[i]<=a; i++){
        while(a%prime[i]==0){
             a=a/prime[i];
             cnt++;
        }
        if(cnt)
            prime_fact.push_back({prime[i],cnt});
    }
    if(a>1){
        prime_fact.push_back({a,1});
    }

}