
int stirling(int n)//base 10
{
         return floor(((n+0.5)*log(n)-n+
         0.5*log(2*pi))/log(10))+1;
}


//or


//int digits_in_factorial(n, b=10){
    //return floor( lgammaf(n+1)/log(b) ) + 1;}//number too small

int stirling(n, b=10){
    return floor( ((n+0.5)*log(n)-n+0.5*log(2*pi))/log(b))+1;}
					    ///number too large