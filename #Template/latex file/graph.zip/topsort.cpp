#define mx 100005
int n,m,f=0;
vector<int>adj[mx],arr;
bool vis[mx],finish[mx];
 
void topsort(int s){
    vis[s]=true;
 
    for(int v:adj[s])
    {
        if( !vis[v])
            topsort(v);
        else if(vis[v] && finish[v]==0) f=1;
 
    }
    finish[s]=1;
    arr.push_back(s+1);
 
 
}