int make_int(string s)//s represent binary form of a  number 
{
    int sum=0;
    reverse(all(s));
    for(int i=0; i<s.size(); i++)
    {
        sum+=(s[i]-'0')*pow(2,i);
    }
    return sum;
}