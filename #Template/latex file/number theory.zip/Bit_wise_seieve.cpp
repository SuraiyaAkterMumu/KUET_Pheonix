int prime[M/64+4];
int check(lli n)
{   return prime[n>>6]&(1<<((n>>1)&31));
}
void seter(lli n)
{   prime[n>>6]|=(1<<((n>>1)&31));
}
void bitwise_sieve(lli p)
{   for(lli i=3; i*i<=p; i+=2)
    {   if(check(i)==0)
        {   for(lli j=i*i; j<=p; j+=(2*i))
                seter(j);
        }
    }
    vprime.pb(2);
    for(lli i=3; i<=p; i+=2)
    {   if(check(i)==0)
        {   vprime.pb(i);
        }
    }
    return;
}